import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Export estático: o site é servido pelo mesmo nginx/Docker do deploy atual (EasyPanel).
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
