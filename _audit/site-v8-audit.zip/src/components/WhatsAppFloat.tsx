"use client";

import { usePathname } from "next/navigation";
import { WHATSAPP_NUMBER, WA_MESSAGES } from "@/lib/site";

/**
 * Botão flutuante de WhatsApp — presente em todas as páginas.
 * Mensagem contextualizada pela página atual + URL + UTMs anexadas no clique.
 */
export default function WhatsAppFloat() {
  const pathname = usePathname() || "/";

  function contextMessage(): string {
    if (pathname.includes("sistema") || pathname.includes("saas") || pathname.includes("crm") || pathname.includes("integracoes")) {
      return WA_MESSAGES.sistemas;
    }
    if (pathname.includes("inteligencia-artificial") || pathname.includes("automacao") || pathname.includes("agentes-de-ia") || pathname.includes("chatbot")) {
      return WA_MESSAGES.ia;
    }
    if (pathname.includes("marketing") || pathname.includes("trafego") || pathname.includes("seo") || pathname.includes("landing") || pathname.includes("tracking")) {
      return WA_MESSAGES.marketing;
    }
    return WA_MESSAGES.default;
  }

  function handleClick(e: React.MouseEvent<HTMLAnchorElement>) {
    e.preventDefault();
    let text = contextMessage();
    try {
      const url = new URL(window.location.href);
      const utms = ["utm_source", "utm_medium", "utm_campaign"]
        .map((k) => (url.searchParams.get(k) ? `${k}=${url.searchParams.get(k)}` : null))
        .filter(Boolean)
        .join(" | ");
      text += `\n\nPágina: ${url.origin}${url.pathname}`;
      if (utms) text += `\nOrigem: ${utms}`;
    } catch {
      /* mantém a mensagem base */
    }
    window.open(
      `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`,
      "_blank",
      "noopener,noreferrer"
    );
  }

  // não competir com o CTA do quiz na própria página de diagnóstico
  if (pathname.startsWith("/diagnostico")) return null;

  return (
    <a
      href={`https://wa.me/${WHATSAPP_NUMBER}`}
      onClick={handleClick}
      className="wa-float"
      aria-label="Falar com a FlowAI pelo WhatsApp"
    >
      <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        <path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.33 4.95L2 22l5.3-1.39a9.87 9.87 0 0 0 4.74 1.21h.01c5.45 0 9.9-4.44 9.9-9.9a9.83 9.83 0 0 0-2.9-7A9.83 9.83 0 0 0 12.04 2Zm0 18.15h-.01a8.2 8.2 0 0 1-4.18-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.25-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.23-8.24 8.23Zm4.52-6.16c-.25-.13-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.24-.64.8-.78.97-.14.16-.29.18-.54.06-.25-.13-1.05-.39-2-1.23-.73-.66-1.23-1.47-1.38-1.72-.14-.25-.01-.38.11-.51.11-.11.25-.29.37-.43.12-.14.16-.25.25-.41.08-.17.04-.31-.02-.43-.06-.13-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.22.25-.86.85-.86 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.6.19 1.14.16 1.57.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.06-.1-.23-.16-.48-.29Z" />
      </svg>
      <span className="sr-only">Conversar no WhatsApp</span>
    </a>
  );
}
