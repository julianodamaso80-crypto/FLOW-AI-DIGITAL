"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";

/**
 * Ativa a revelação por scroll com IntersectionObserver.
 * - Sem JS: nada fica escondido (classe js-anim nunca é aplicada).
 * - prefers-reduced-motion: conteúdo sempre visível (CSS ignora as transições).
 */
export default function RevealInit() {
  const pathname = usePathname();

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      document.documentElement.classList.remove("js-anim");
      return;
    }
    document.documentElement.classList.add("js-anim");

    const els = Array.from(document.querySelectorAll<HTMLElement>(".reveal"));
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 }
    );
    els.forEach((el) => {
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.92) {
        el.classList.add("is-visible");
      } else {
        io.observe(el);
      }
    });
    return () => io.disconnect();
  }, [pathname]);

  return null;
}
