"use client";

import { useEffect } from "react";

/**
 * Animações cinematográficas da home com GSAP + ScrollTrigger.
 * Regras de segurança:
 *  - Carrega GSAP dinamicamente só quando fará uso real (code splitting).
 *  - Desativado com prefers-reduced-motion (fica só o conteúdo estático).
 *  - Desativado em aparelhos fracos (memória < 4GB ou tela pequena sem pointer fine).
 *  - Todo conteúdo permanece visível e legível sem animação (fallback CSS).
 */
export default function HomeScenes() {
  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) return;

    type NavWithMemory = Navigator & { deviceMemory?: number };
    const nav = navigator as NavWithMemory;
    const weakDevice =
      (nav.deviceMemory !== undefined && nav.deviceMemory < 4) ||
      (window.innerWidth < 768 && !window.matchMedia("(pointer: fine)").matches);

    let ctx: { revert: () => void } | null = null;
    let cancelled = false;

    (async () => {
      const [{ gsap }, { ScrollTrigger }] = await Promise.all([
        import("gsap"),
        import("gsap/ScrollTrigger"),
      ]);
      if (cancelled) return;
      gsap.registerPlugin(ScrollTrigger);

      ctx = gsap.context(() => {
        // CENA 1 — parallax sutil do núcleo no hero
        if (!weakDevice) {
          gsap.to("[data-scene='core']", {
            yPercent: -12,
            ease: "none",
            scrollTrigger: {
              trigger: "[data-scene='hero']",
              start: "top top",
              end: "bottom top",
              scrub: 0.6,
            },
          });
        }

        // CENA 2 — fragmentos dispersos se organizam durante a rolagem
        const frags = gsap.utils.toArray<HTMLElement>("[data-frag]");
        if (frags.length) {
          frags.forEach((el, i) => {
            const dx = [(i % 3) - 1, ((i + 1) % 3) - 1][0] * (weakDevice ? 24 : 72);
            const rot = ((i % 5) - 2) * (weakDevice ? 1.5 : 4);
            gsap.from(el, {
              x: dx,
              y: 40 + (i % 4) * 18,
              rotate: rot,
              opacity: 0.25,
              ease: "power2.out",
              scrollTrigger: {
                trigger: "[data-scene='fragmentacao']",
                start: "top 78%",
                end: "top 22%",
                scrub: 0.8,
              },
            });
          });
          gsap.from("[data-frag-line]", {
            scaleX: 0,
            transformOrigin: "left center",
            ease: "power2.out",
            scrollTrigger: {
              trigger: "[data-scene='fragmentacao']",
              start: "top 45%",
              end: "top 12%",
              scrub: 0.8,
            },
          });
        }

        // CENA 4 — etapas do fluxo de marketing acendem em sequência
        const steps = gsap.utils.toArray<HTMLElement>("[data-pipe-step]");
        steps.forEach((el, i) => {
          gsap.from(el, {
            opacity: 0,
            y: 26,
            duration: 0.55,
            delay: i * 0.08,
            ease: "power2.out",
            scrollTrigger: { trigger: el, start: "top 88%" },
          });
        });

        // CENA 7 — linha de conexão entre pilares desenha na rolagem
        const connector = document.querySelector<SVGPathElement>("[data-connect-path]");
        if (connector) {
          const len = connector.getTotalLength();
          gsap.set(connector, { strokeDasharray: len, strokeDashoffset: len });
          gsap.to(connector, {
            strokeDashoffset: 0,
            ease: "none",
            scrollTrigger: {
              trigger: "[data-scene='conexao']",
              start: "top 75%",
              end: "top 20%",
              scrub: 0.7,
            },
          });
        }
      });
    })();

    return () => {
      cancelled = true;
      if (ctx) ctx.revert();
    };
  }, []);

  return null;
}
