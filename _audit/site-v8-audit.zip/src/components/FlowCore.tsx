/**
 * O NÚCLEO FLOWAI — três fluxos (Marketing, IA, Sistemas) convergem
 * para um núcleo central e saem transformados em resultados.
 * SVG leve + CSS puro (sem canvas). Nomes em HTML real por acessibilidade/SEO.
 */
export default function FlowCore() {
  return (
    <div className="relative mx-auto w-full max-w-3xl" aria-hidden="false">
      <svg
        viewBox="0 0 760 420"
        className="h-auto w-full"
        role="img"
        aria-label="Diagrama: marketing, inteligência artificial e sistemas convergindo para o núcleo FlowAI e gerando leads, automação, dados e escala"
      >
        <defs>
          <linearGradient id="flow-gradient" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#FF6A00" />
            <stop offset="100%" stopColor="#FFB347" />
          </linearGradient>
          <linearGradient id="flow-gradient-cool" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#2B313A" />
            <stop offset="100%" stopColor="#FF6A00" />
          </linearGradient>
          <radialGradient id="core-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FF6A00" stopOpacity="0.55" />
            <stop offset="55%" stopColor="#FF6A00" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#FF6A00" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Brilho do núcleo */}
        <circle cx="380" cy="210" r="150" fill="url(#core-glow)" />

        {/* Fluxos de entrada */}
        <path
          d="M20 90 C 160 90, 220 160, 320 190"
          fill="none"
          stroke="url(#flow-gradient-cool)"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.85"
        />
        <path
          d="M20 210 C 140 210, 220 210, 316 210"
          fill="none"
          stroke="url(#flow-gradient-cool)"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.85"
        />
        <path
          d="M20 330 C 160 330, 220 260, 320 230"
          fill="none"
          stroke="url(#flow-gradient-cool)"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.85"
        />

        {/* Pulsos animados sobre os fluxos (CSS, pausa com reduced-motion) */}
        <path
          className="flow-animated"
          d="M20 90 C 160 90, 220 160, 320 190"
          fill="none"
          stroke="#FFB347"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path
          className="flow-animated"
          d="M20 210 C 140 210, 220 210, 316 210"
          fill="none"
          stroke="#FFB347"
          strokeWidth="3"
          strokeLinecap="round"
          style={{ animationDelay: "-2s" } as React.CSSProperties}
        />
        <path
          className="flow-animated"
          d="M20 330 C 160 330, 220 260, 320 230"
          fill="none"
          stroke="#FFB347"
          strokeWidth="3"
          strokeLinecap="round"
          style={{ animationDelay: "-4s" } as React.CSSProperties}
        />

        {/* Núcleo */}
        <circle cx="380" cy="210" r="64" fill="#0F141B" stroke="rgba(255,179,71,0.5)" strokeWidth="1.5" />
        <circle cx="380" cy="210" r="46" fill="none" stroke="rgba(255,106,0,0.55)" strokeWidth="1" strokeDasharray="3 6" />
        <circle className="node-pulse" cx="380" cy="210" r="12" fill="#FF6A00" />

        {/* Fluxos de saída */}
        <path
          d="M440 190 C 540 160, 600 90, 740 90"
          fill="none"
          stroke="url(#flow-gradient)"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.9"
        />
        <path
          d="M444 210 C 560 210, 620 210, 740 210"
          fill="none"
          stroke="url(#flow-gradient)"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.9"
        />
        <path
          d="M440 230 C 540 260, 600 330, 740 330"
          fill="none"
          stroke="url(#flow-gradient)"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity="0.9"
        />

        {/* Nós de dados */}
        {[
          [20, 90],
          [20, 210],
          [20, 330],
          [740, 90],
          [740, 210],
          [740, 330],
        ].map(([cx, cy], i) => (
          <circle
            key={i}
            className="node-pulse"
            cx={cx}
            cy={cy}
            r="7"
            fill={cx < 400 ? "#2B313A" : "#FF6A00"}
            stroke="#FFB347"
            strokeWidth="1.5"
            style={{ animationDelay: `${i * 0.5}s` } as React.CSSProperties}
          />
        ))}
      </svg>

      {/* Rótulos em HTML real (não em canvas), como exige o briefing */}
      <div className="pointer-events-none absolute inset-0 hidden text-[13px] font-bold tracking-wide sm:block">
        <span className="absolute left-0 top-[13%] -translate-y-1/2 text-flow-soft">Marketing</span>
        <span className="absolute left-0 top-[46%] -translate-y-1/2 text-flow-soft">IA</span>
        <span className="absolute left-0 top-[74%] -translate-y-1/2 text-flow-soft">Sistemas</span>
        <span className="absolute right-0 top-[13%] -translate-y-1/2 text-flow-amber">Leads</span>
        <span className="absolute right-0 top-[46%] -translate-y-1/2 text-flow-amber">Automação</span>
        <span className="absolute right-0 top-[74%] -translate-y-1/2 text-flow-amber">Dados e escala</span>
      </div>

      {/* Versão mobile dos rótulos */}
      <div className="mt-3 flex flex-wrap justify-center gap-2 sm:hidden">
        {["Marketing", "IA", "Sistemas", "→", "Leads", "Automação", "Escala"].map((t) => (
          <span key={t} className="chip !text-[12px]">
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}
