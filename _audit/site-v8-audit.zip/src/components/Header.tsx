"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { SERVICES_NAV, PILLAR_LABELS, buildWaLink } from "@/lib/site";

const NAV_LINKS = [
  { title: "Como funciona", href: "/#como-trabalhamos" },
  { title: "Cases", href: "/cases/" },
  { title: "Conteúdo", href: "/blog/" },
  { title: "Sobre", href: "/sobre/" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [solutionsOpen, setSolutionsOpen] = useState(false);
  const solutionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (solutionsRef.current && !solutionsRef.current.contains(e.target as Node)) {
        setSolutionsOpen(false);
      }
    }
    function onEsc(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setSolutionsOpen(false);
        setOpen(false);
      }
    }
    document.addEventListener("click", onClickOutside);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("click", onClickOutside);
      document.removeEventListener("keydown", onEsc);
    };
  }, []);

  // trava o scroll com menu mobile aberto
  useEffect(() => {
    document.documentElement.style.overflow = open ? "hidden" : "";
    return () => {
      document.documentElement.style.overflow = "";
    };
  }, [open]);

  const pillars: Array<"marketing" | "ia" | "sistemas"> = ["marketing", "ia", "sistemas"];

  return (
    <header
      className={`site-header fixed inset-x-0 top-0 z-50 ${scrolled ? "is-scrolled" : ""}`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3 lg:px-8">
        <Link href="/" aria-label="FlowAI Digital — página inicial" className="shrink-0">
          {/* Manual da marca: assinatura completa com largura mínima de 180px no digital */}
          <Image
            src="/assets/logo/flowai-logo-144.webp"
            alt="FlowAI Digital"
            width={385}
            height={144}
            priority
            className={`h-auto transition-all ${scrolled ? "w-[180px]" : "w-[200px]"}`}
          />
        </Link>

        {/* Navegação desktop */}
        <nav aria-label="Navegação principal" className="hidden items-center gap-7 lg:flex">
          <div className="relative" ref={solutionsRef}>
            <button
              type="button"
              className="flex items-center gap-1.5 text-sm font-semibold text-flow-soft hover:text-white"
              aria-expanded={solutionsOpen}
              aria-haspopup="true"
              onClick={() => setSolutionsOpen((v) => !v)}
            >
              Soluções
              <svg width="10" height="6" viewBox="0 0 10 6" fill="none" aria-hidden="true">
                <path d="M1 1l4 4 4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
              </svg>
            </button>
            {solutionsOpen && (
              <div className="absolute left-1/2 top-full z-50 mt-4 w-[720px] -translate-x-1/2 rounded-2xl border border-flow-line bg-flow-deep p-6 shadow-2xl">
                <div className="grid grid-cols-3 gap-6">
                  {pillars.map((pillar) => (
                    <div key={pillar}>
                      <p className="eyebrow mb-3 !text-[11px]">{PILLAR_LABELS[pillar]}</p>
                      <ul className="space-y-1.5">
                        {SERVICES_NAV.filter((s) => s.pillar === pillar).map((s) => (
                          <li key={s.href}>
                            <Link
                              href={s.href}
                              className="block rounded-lg px-2 py-1.5 text-[13.5px] text-flow-muted hover:bg-white/5 hover:text-white"
                              onClick={() => setSolutionsOpen(false)}
                            >
                              {s.title}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {NAV_LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="text-sm font-semibold text-flow-soft hover:text-white"
            >
              {l.title}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={buildWaLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-semibold text-flow-soft hover:text-white"
          >
            WhatsApp
          </a>
          <Link href="/diagnostico/" className="btn btn--primary !px-6 !py-3 text-sm">
            Fazer diagnóstico
          </Link>
        </div>

        {/* Botão menu mobile */}
        <button
          type="button"
          className="flex h-11 w-11 items-center justify-center rounded-xl border border-flow-line lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? (
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
              <path d="M2 2l14 14M16 2L2 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          ) : (
            <svg width="20" height="14" viewBox="0 0 20 14" fill="none" aria-hidden="true">
              <path d="M1 1h18M1 7h18M1 13h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          )}
        </button>
      </div>

      {/* Menu mobile */}
      {open && (
        <div
          id="mobile-menu"
          className="max-h-[calc(100dvh-64px)] overflow-y-auto border-t border-flow-line bg-flow-black px-5 pb-28 pt-4 lg:hidden"
        >
          <p className="eyebrow mb-3">Soluções</p>
          <ul className="mb-6 space-y-1">
            {SERVICES_NAV.map((s) => (
              <li key={s.href}>
                <Link
                  href={s.href}
                  className="block rounded-lg px-2 py-2.5 text-[15px] font-medium text-flow-soft hover:bg-white/5"
                  onClick={() => setOpen(false)}
                >
                  {s.title}
                </Link>
              </li>
            ))}
          </ul>
          <ul className="mb-8 space-y-1 border-t border-flow-line pt-4">
            {NAV_LINKS.concat([{ title: "Contato", href: "/contato/" }]).map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  className="block rounded-lg px-2 py-2.5 text-[15px] font-semibold hover:bg-white/5"
                  onClick={() => setOpen(false)}
                >
                  {l.title}
                </Link>
              </li>
            ))}
          </ul>
          <div className="grid gap-3">
            <Link href="/diagnostico/" className="btn btn--primary w-full" onClick={() => setOpen(false)}>
              Fazer diagnóstico
            </Link>
            <a
              href={buildWaLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn--ghost w-full"
            >
              Falar pelo WhatsApp
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
