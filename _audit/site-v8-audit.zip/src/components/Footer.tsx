import Link from "next/link";
import Image from "next/image";
import { SERVICES_NAV, WHATSAPP_DISPLAY, INSTAGRAM_URL, buildWaLink } from "@/lib/site";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-flow-line bg-flow-deep">
      <div className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div>
            {/* Manual da marca: assinatura completa com largura mínima de 180px no digital */}
            <Image
              src="/assets/logo/flowai-logo-144.webp"
              alt="FlowAI Digital"
              width={385}
              height={144}
              className="h-auto w-[210px]"
            />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-flow-muted">
              Marketing, inteligência artificial e sistemas sob medida. Tudo
              conectado para sua empresa crescer.
            </p>
            <p className="mt-5 text-sm text-flow-muted">
              Rio de Janeiro · Brasil
              <br />
              Atendimento para empresas em todo o Brasil.
            </p>
          </div>

          <nav aria-label="Serviços">
            <p className="eyebrow mb-4">Serviços</p>
            <ul className="space-y-2.5">
              {SERVICES_NAV.slice(0, 8).map((s) => (
                <li key={s.href}>
                  <Link href={s.href} className="text-sm text-flow-muted hover:text-white">
                    {s.title}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Mais serviços e conteúdo">
            <p className="eyebrow mb-4">Empresa</p>
            <ul className="space-y-2.5">
              {SERVICES_NAV.slice(8).map((s) => (
                <li key={s.href}>
                  <Link href={s.href} className="text-sm text-flow-muted hover:text-white">
                    {s.title}
                  </Link>
                </li>
              ))}
              <li>
                <Link href="/cases/" className="text-sm text-flow-muted hover:text-white">
                  Cases
                </Link>
              </li>
              <li>
                <Link href="/blog/" className="text-sm text-flow-muted hover:text-white">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/sobre/" className="text-sm text-flow-muted hover:text-white">
                  Sobre a FlowAI
                </Link>
              </li>
            </ul>
          </nav>

          <div>
            <p className="eyebrow mb-4">Contato</p>
            <ul className="space-y-2.5 text-sm text-flow-muted">
              <li>
                <a
                  href={buildWaLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  WhatsApp: {WHATSAPP_DISPLAY}
                </a>
              </li>
              <li>
                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  Instagram
                </a>
              </li>
              <li>
                <Link href="/contato/" className="hover:text-white">
                  Página de contato
                </Link>
              </li>
              <li>
                <Link href="/diagnostico/" className="hover:text-white">
                  Diagnóstico gratuito
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-flow-line pt-7 text-[13px] text-flow-muted md:flex-row md:items-center md:justify-between">
          <p>© {year} FlowAI Digital. Todos os direitos reservados.</p>
          <div className="flex gap-6">
            <Link href="/politica-de-privacidade/" className="hover:text-white">
              Política de Privacidade
            </Link>
            <Link href="/termos-de-uso/" className="hover:text-white">
              Termos de Uso
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
