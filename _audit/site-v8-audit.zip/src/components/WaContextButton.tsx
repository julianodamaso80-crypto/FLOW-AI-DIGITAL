"use client";

import { WHATSAPP_NUMBER, WA_MESSAGES } from "@/lib/site";

/**
 * Botão de WhatsApp com mensagem contextualizada por serviço,
 * anexando URL atual e UTMs no momento do clique.
 */
export default function WaContextButton({
  waKey,
  label,
  className,
}: {
  waKey: keyof typeof WA_MESSAGES;
  label: string;
  className?: string;
}) {
  function handleClick(e: React.MouseEvent<HTMLAnchorElement>) {
    e.preventDefault();
    let text = WA_MESSAGES[waKey] ?? WA_MESSAGES.default;
    try {
      const url = new URL(window.location.href);
      const utms = ["utm_source", "utm_medium", "utm_campaign"]
        .map((k) => (url.searchParams.get(k) ? `${k}=${url.searchParams.get(k)}` : null))
        .filter(Boolean)
        .join(" | ");
      text += `\n\nPágina: ${url.origin}${url.pathname}`;
      if (utms) text += `\nOrigem: ${utms}`;
    } catch {
      /* mensagem base */
    }
    window.open(
      `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`,
      "_blank",
      "noopener,noreferrer"
    );
  }

  return (
    <a
      href={`https://wa.me/${WHATSAPP_NUMBER}`}
      onClick={handleClick}
      className={className}
      target="_blank"
      rel="noopener noreferrer"
    >
      {label}
    </a>
  );
}
