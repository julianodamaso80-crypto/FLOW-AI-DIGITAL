"use client";

import { useId, useState } from "react";

export interface FaqEntry {
  q: string;
  a: string;
}

/** Acordeão de FAQ acessível: teclado, aria-expanded, conteúdo real no HTML. */
export default function Faq({ items }: { items: FaqEntry[] }) {
  const baseId = useId();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div>
      {items.map((item, i) => {
        const open = openIndex === i;
        return (
          <div className="faq-item" key={i}>
            <h3 className="m-0">
              <button
                type="button"
                className="faq-trigger"
                aria-expanded={open}
                aria-controls={`${baseId}-panel-${i}`}
                id={`${baseId}-trigger-${i}`}
                onClick={() => setOpenIndex(open ? null : i)}
              >
                {item.q}
                <svg
                  className="faq-icon"
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                  aria-hidden="true"
                >
                  <path d="M8 1v14M1 8h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </button>
            </h3>
            <div
              id={`${baseId}-panel-${i}`}
              role="region"
              aria-labelledby={`${baseId}-trigger-${i}`}
              className="faq-panel"
              hidden={!open}
            >
              <div>{item.a}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
