import type { Metadata } from "next";
import Link from "next/link";
import FlowCore from "@/components/FlowCore";
import HomeScenes from "@/components/HomeScenes";
import Faq from "@/components/Faq";
import JsonLd from "@/components/JsonLd";
import { faqSchema } from "@/lib/schema";
import { buildWaLink, WA_MESSAGES } from "@/lib/site";

export const metadata: Metadata = {
  title: "FlowAI Digital — Marketing, IA e Sistemas Sob Medida para Empresas",
  description:
    "Marketing digital, inteligência artificial, automação e desenvolvimento de sistemas personalizados trabalhando como uma só operação. Diagnóstico gratuito pelo site.",
  alternates: { canonical: "/" },
  openGraph: {
    title: "FlowAI Digital — Marketing, IA e Sistemas Sob Medida",
    description:
      "Marketing, inteligência artificial e sistemas sob medida. Tudo conectado para sua empresa crescer.",
    url: "/",
  },
};

const HOME_FAQ = [
  {
    q: "A FlowAI é uma agência de marketing ou uma empresa de tecnologia?",
    a: "As duas coisas, de forma integrada. A FlowAI reúne marketing digital (estratégia, mídia, conteúdo, SEO e conversão), inteligência artificial e automação, e desenvolvimento de sistemas personalizados. O diferencial é que essas frentes trabalham como uma só operação: a campanha, o atendimento, o CRM e o sistema conversam entre si.",
  },
  {
    q: "Preciso contratar os três pilares juntos?",
    a: "Não. Cada projeto começa pelo diagnóstico, que identifica a prioridade real da sua operação. Algumas empresas começam pelo marketing, outras por uma automação específica ou por um sistema. A arquitetura é pensada para crescer por etapas.",
  },
  {
    q: "Como funciona o desenvolvimento de um sistema personalizado?",
    a: "Começa com o mapeamento do seu processo real, seguido de arquitetura da solução, protótipo, desenvolvimento em ciclos curtos, integração com as ferramentas que você já usa, testes, implantação e evolução contínua. Você acompanha o progresso em cada etapa.",
  },
  {
    q: "A IA substitui a minha equipe de atendimento?",
    a: "Não é esse o objetivo. A automação cuida da repetição — primeiras respostas, qualificação, follow-up, atualização de CRM — e a sua equipe continua cuidando das decisões e das conversas que exigem gente. Processos críticos podem incluir aprovação humana.",
  },
  {
    q: "Quanto custa um projeto com a FlowAI?",
    a: "Depende do escopo. Um projeto de marketing tem estrutura de investimento diferente de uma automação ou de um software sob medida. Após o diagnóstico gratuito, você recebe uma proposta com escopo claro, etapas e investimento — sem surpresa e sem compromisso.",
  },
  {
    q: "Em quanto tempo vejo resultado?",
    a: "Depende da frente e do ponto de partida da sua operação — e por isso não prometemos prazos ou números garantidos. O que garantimos é método: metas definidas em conjunto, acompanhamento transparente e ajustes contínuos com base em dados.",
  },
  {
    q: "O código do sistema desenvolvido é meu?",
    a: "Sim. Sistemas desenvolvidos sob medida para a sua empresa pertencem a você, com documentação e entrega organizada. Essa condição fica registrada em contrato.",
  },
  {
    q: "Vocês atendem empresas fora do Rio de Janeiro?",
    a: "Sim. A FlowAI é sediada no Rio de Janeiro e atende empresas de todo o Brasil, com reuniões online e acompanhamento remoto estruturado.",
  },
  {
    q: "Como meus dados são tratados no diagnóstico?",
    a: "Os dados informados no diagnóstico são usados apenas para analisar seu cenário e entrar em contato sobre as soluções apresentadas, conforme a nossa Política de Privacidade. Você pode solicitar a exclusão a qualquer momento.",
  },
  {
    q: "O que acontece depois do diagnóstico?",
    a: "Você recebe uma leitura inicial do seu cenário com a prioridade recomendada e conversa com um especialista pelo WhatsApp. A validação completa acontece em uma reunião de análise da operação — sem custo e sem obrigação de fechar.",
  },
];

export default function Home() {
  return (
    <>
      <HomeScenes />
      <JsonLd data={faqSchema(HOME_FAQ)} />

      {/* ============ CENA 1 — O NÚCLEO FLOWAI ============ */}
      <section
        data-scene="hero"
        className="relative overflow-hidden pb-20 pt-32 md:pt-40"
        style={{
          background:
            "radial-gradient(1200px 600px at 50% -10%, rgba(255,106,0,0.10), transparent 60%), linear-gradient(180deg, #0F141B 0%, #070A0F 70%)",
        }}
      >
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <p className="chip hero-enter mx-auto">
              <span className="kbd-dot" aria-hidden="true" />
              Marketing · Inteligência artificial · Sistemas
            </p>
            <h1 className="h-display mt-7 text-4xl sm:text-5xl lg:text-[64px]">
              Marketing, inteligência artificial e sistemas sob medida.{" "}
              <span className="text-flow-orange">Tudo conectado</span> para sua
              empresa crescer.
            </h1>
            <p className="hero-enter mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-flow-muted" style={{ ["--enter-delay" as string]: "160ms" }}>
              A FlowAI integra estratégia, mídia, conteúdo, automação e
              desenvolvimento de software para transformar operações dispersas
              em uma estrutura organizada, mensurável e escalável.
            </p>
            <div className="hero-enter mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row" style={{ ["--enter-delay" as string]: "240ms" }}>
              <Link href="/diagnostico/" className="btn btn--primary w-full sm:w-auto">
                Diagnosticar minha empresa
              </Link>
              <a
                href={buildWaLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn--ghost w-full sm:w-auto"
              >
                Falar com um especialista
              </a>
            </div>
          </div>

          <div data-scene="core" className="hero-enter mt-16" style={{ ["--enter-delay" as string]: "320ms" }}>
            <FlowCore />
          </div>

          <p className="mt-10 text-center text-sm text-flow-muted">
            Uma só operação: o marketing gera oportunidades, a IA organiza e
            executa, o sistema registra e escala.
          </p>

          <div className="mt-12 flex justify-center" aria-hidden="true">
            <div className="flex h-12 w-7 items-start justify-center rounded-full border border-flow-line p-1.5">
              <div className="node-pulse h-2 w-2 rounded-full bg-flow-orange" />
            </div>
          </div>
        </div>
      </section>

      {/* ============ CENA 2 — O PROBLEMA DA FRAGMENTAÇÃO ============ */}
      <section data-scene="fragmentacao" className="relative py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="eyebrow reveal">O problema</p>
            <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl lg:text-5xl">
              Sua empresa não precisa de mais ferramentas desconectadas.
            </h2>
            <p className="reveal mx-auto mt-5 max-w-2xl text-flow-muted">
              A maioria das operações não sofre por falta de ferramenta — sofre
              porque nada conversa com nada. O resultado é retrabalho, lead sem
              resposta e decisão no escuro.
            </p>
          </div>

          <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Marketing sem rastreamento", "Campanhas rodando sem saber qual delas gera venda de verdade."],
              ["Leads sem atendimento", "Oportunidades chegam e esfriam esperando alguém responder."],
              ["CRM sem utilização", "A ferramenta existe, mas o processo vive em planilhas paralelas."],
              ["Tarefas repetitivas", "Horas da equipe gastas em copiar, colar e conferir informação."],
              ["Sistemas que não conversam", "Cada área com um software, nenhum integrado ao outro."],
              ["Processos dependentes de pessoas", "Se alguém sai de férias, uma parte da operação para."],
              ["Dados espalhados", "Cada relatório conta uma história diferente da mesma empresa."],
              ["Falta de visão da operação", "Ninguém enxerga o funil inteiro, do anúncio ao contrato."],
            ].map(([title, desc], i) => (
              <div key={title} data-frag className="card reveal p-6" style={{ ["--reveal-delay" as string]: `${(i % 4) * 70}ms` }}>
                <h3 className="text-[15.5px] font-bold">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-flow-muted">{desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-12" aria-hidden="true">
            <div data-frag-line className="hr-flow" />
          </div>
          <p className="reveal mx-auto mt-8 max-w-xl text-center font-semibold text-flow-soft">
            A FlowAI existe para conectar essas pontas em uma única operação.
          </p>
        </div>
      </section>

      {/* ============ CENA 3 — OS TRÊS PILARES ============ */}
      <section id="pilares" className="surface-deep py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="eyebrow reveal">Posicionamento</p>
            <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl lg:text-5xl">
              Uma empresa. Três competências. Uma operação conectada.
            </h2>
          </div>

          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            {/* Pilar 1 */}
            <article className="card card--hover reveal flex flex-col p-8">
              <p className="eyebrow !text-[11px]">01 · Marketing e Crescimento</p>
              <h3 className="mt-3 text-2xl font-extrabold">
                Atrair e converter as oportunidades certas.
              </h3>
              <p className="mt-4 flex-1 text-[15px] leading-relaxed text-flow-muted">
                Estratégia, tráfego pago, SEO, conteúdo, landing pages, funis e
                CRO — com tracking configurado para você saber de onde vem cada
                oportunidade.
              </p>
              <ul className="mt-6 space-y-2 text-sm text-flow-soft">
                {["Gestão de tráfego pago (Meta e Google)", "SEO, conteúdo e visibilidade em buscas e IA", "Sites e landing pages orientados à conversão", "Tracking, analytics e dashboards"].map((t) => (
                  <li key={t} className="flex gap-2.5">
                    <span className="kbd-dot mt-1.5 shrink-0" aria-hidden="true" />
                    {t}
                  </li>
                ))}
              </ul>
              <Link href="/agencia-de-marketing-digital/" className="mt-7 font-bold text-flow-amber hover:text-white">
                Conhecer o pilar de marketing →
              </Link>
            </article>

            {/* Pilar 2 */}
            <article className="card card--hover reveal flex flex-col p-8" style={{ ["--reveal-delay" as string]: "90ms" }}>
              <p className="eyebrow !text-[11px]">02 · IA e Automação</p>
              <h3 className="mt-3 text-2xl font-extrabold">
                Automatizar a repetição. Manter pessoas nas decisões.
              </h3>
              <p className="mt-4 flex-1 text-[15px] leading-relaxed text-flow-muted">
                Agentes de IA e automações que respondem, qualificam, organizam
                e acompanham — integrados ao WhatsApp, ao CRM e às ferramentas
                que sua empresa já usa.
              </p>
              <ul className="mt-6 space-y-2 text-sm text-flow-soft">
                {["Atendimento e qualificação com IA no WhatsApp", "Follow-up e cadências automáticas", "Automação de processos internos e documentos", "Processos com aprovação humana quando necessário"].map((t) => (
                  <li key={t} className="flex gap-2.5">
                    <span className="kbd-dot mt-1.5 shrink-0" aria-hidden="true" />
                    {t}
                  </li>
                ))}
              </ul>
              <Link href="/agencia-de-inteligencia-artificial/" className="mt-7 font-bold text-flow-amber hover:text-white">
                Conhecer o pilar de IA →
              </Link>
            </article>

            {/* Pilar 3 */}
            <article className="card card--hover reveal flex flex-col p-8" style={{ ["--reveal-delay" as string]: "180ms" }}>
              <p className="eyebrow !text-[11px]">03 · Sistemas Personalizados</p>
              <h3 className="mt-3 text-2xl font-extrabold">
                Quando o sistema pronto não acompanha, construímos o seu.
              </h3>
              <p className="mt-4 flex-1 text-[15px] leading-relaxed text-flow-muted">
                Software sob medida para o processo específico da sua empresa:
                CRM, ERP, portais, painéis, aplicativos, SaaS e integrações —
                desenvolvidos para evoluir com o negócio.
              </p>
              <ul className="mt-6 space-y-2 text-sm text-flow-soft">
                {["Sistemas web e plataformas internas", "CRM e ERP personalizados", "SaaS, MVP e produtos digitais", "Integração com APIs e sistemas existentes"].map((t) => (
                  <li key={t} className="flex gap-2.5">
                    <span className="kbd-dot mt-1.5 shrink-0" aria-hidden="true" />
                    {t}
                  </li>
                ))}
              </ul>
              <Link href="/desenvolvimento-de-sistemas-personalizados/" className="mt-7 font-bold text-flow-amber hover:text-white">
                Conhecer o pilar de sistemas →
              </Link>
            </article>
          </div>
        </div>
      </section>

      {/* ============ CENA 4 — MARKETING (fluxo do anúncio à venda) ============ */}
      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="grid items-start gap-12 lg:grid-cols-2">
            <div className="lg:sticky lg:top-28">
              <p className="eyebrow reveal">Marketing e crescimento</p>
              <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl">
                Do anúncio à venda, cada etapa rastreada.
              </h2>
              <p className="reveal mt-5 max-w-lg leading-relaxed text-flow-muted">
                Campanha boa não é a que gera clique — é a que gera cliente. A
                FlowAI estrutura o caminho completo: mídia, página, captação,
                atendimento e CRM, com dados conectados de ponta a ponta para
                otimizar o que realmente traz resultado.
              </p>
              <Link href="/gestao-de-trafego-pago/" className="reveal mt-7 inline-block font-bold text-flow-amber hover:text-white">
                Ver gestão de tráfego pago →
              </Link>
            </div>

            <ol className="relative space-y-3" aria-label="Fluxo de marketing da FlowAI">
              {[
                ["Anúncio", "Campanhas em Meta e Google com criativos e públicos testados continuamente."],
                ["Página", "Landing page rápida, clara e construída para converter a visita em conversa."],
                ["Lead", "Captação com formulário ou WhatsApp, com origem registrada (UTM, campanha)."],
                ["CRM", "A oportunidade entra no funil automaticamente, sem digitação manual."],
                ["Atendimento", "Resposta rápida — com automação e IA apoiando a equipe comercial."],
                ["Oportunidade", "Qualificação e acompanhamento organizados por etapa do funil."],
                ["Venda", "O fechamento volta para o dado: você sabe qual campanha gerou o contrato."],
              ].map(([title, desc], i) => (
                <li key={title} data-pipe-step className="card flex gap-5 p-5">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-flow-line font-extrabold text-flow-amber" aria-hidden="true">
                    {i + 1}
                  </span>
                  <div>
                    <h3 className="font-bold">{title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-flow-muted">{desc}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* ============ CENA 5 — INTELIGÊNCIA ARTIFICIAL ============ */}
      <section className="surface-deep py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="eyebrow reveal">IA e automação</p>
            <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl lg:text-5xl">
              Agentes que executam tarefas reais da sua operação.
            </h2>
            <p className="reveal mx-auto mt-5 max-w-2xl text-flow-muted">
              Nada de robô genérico: cada agente é configurado para um processo
              específico da sua empresa, com regras claras e supervisão humana
              onde importa.
            </p>
          </div>

          <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              ["Resposta imediata", "O lead que chega pelo site ou WhatsApp recebe o primeiro atendimento na hora, a qualquer horário."],
              ["Qualificação", "O agente entende a necessidade, coleta as informações essenciais e classifica a oportunidade."],
              ["Organização", "Dados do contato entram no CRM estruturados — sem planilha paralela e sem retrabalho."],
              ["Follow-up", "Cadências de acompanhamento que não deixam a conversa morrer por esquecimento."],
              ["Resumo para a equipe", "O vendedor recebe o contexto pronto: quem é o lead, o que pediu, em que etapa está."],
              ["Encaminhamento humano", "Quando o assunto exige gente, a conversa vai para a equipe com todo o histórico."],
            ].map(([title, desc], i) => (
              <div key={title} className="card card--hover reveal p-6" style={{ ["--reveal-delay" as string]: `${(i % 3) * 80}ms` }}>
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-flow-orange/10" aria-hidden="true">
                  <span className="kbd-dot" />
                </div>
                <h3 className="font-bold">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-flow-muted">{desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link href="/agentes-de-ia-para-empresas/" className="btn btn--ghost">
              Ver agentes de IA para empresas
            </Link>
          </div>
        </div>
      </section>

      {/* ============ CENA 6 — SISTEMA PERSONALIZADO ============ */}
      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="eyebrow reveal">Sistemas personalizados</p>
            <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl lg:text-5xl">
              Quando o sistema pronto não acompanha sua empresa, nós construímos o seu.
            </h2>
            <p className="reveal mx-auto mt-5 max-w-2xl text-flow-muted">
              Software genérico obriga a empresa a se adaptar à ferramenta. O
              sistema sob medida faz o contrário: nasce do seu processo e cresce
              com ele.
            </p>
          </div>

          {/* Transformação problema → solução → resultado */}
          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            <div className="card reveal p-8">
              <p className="eyebrow !text-[11px]">Problema atual</p>
              <ul className="mt-4 space-y-2.5 text-[15px] text-flow-muted">
                {["Processos manuais e repetitivos", "Sistemas desconectados entre si", "Planilhas como banco de dados", "Retrabalho e erro humano", "Falta de dado confiável para decidir"].map((t) => (
                  <li key={t} className="flex gap-2.5">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-flow-graphite" aria-hidden="true" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
            <div className="card reveal border-flow-orange/40 p-8" style={{ ["--reveal-delay" as string]: "90ms" }}>
              <p className="eyebrow !text-[11px]">Solução FlowAI</p>
              <ul className="mt-4 space-y-2.5 text-[15px] text-flow-soft">
                {["Mapeamento do processo real", "Arquitetura da solução", "Desenvolvimento sob medida", "Integração com o que já existe", "Implantação acompanhada", "Evolução contínua"].map((t) => (
                  <li key={t} className="flex gap-2.5">
                    <span className="kbd-dot mt-1.5 shrink-0" aria-hidden="true" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
            <div className="card reveal p-8" style={{ ["--reveal-delay" as string]: "180ms" }}>
              <p className="eyebrow !text-[11px]">Resultado esperado</p>
              <ul className="mt-4 space-y-2.5 text-[15px] text-flow-muted">
                {["Mais organização e velocidade", "Rastreabilidade de ponta a ponta", "Controle da operação em um só lugar", "Capacidade de crescer sem caos", "Dados confiáveis para decisões"].map((t) => (
                  <li key={t} className="flex gap-2.5">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-flow-amber" aria-hidden="true" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["CRM personalizado", "/crm-personalizado-e-automacao-de-vendas/"],
              ["Plataformas e portais", "/desenvolvimento-de-sistemas-personalizados/"],
              ["SaaS e MVP", "/desenvolvimento-de-saas-e-mvp/"],
              ["Integrações e APIs", "/integracoes-de-sistemas-e-apis/"],
            ].map(([title, href], i) => (
              <Link key={href} href={href} className="card card--hover reveal flex items-center justify-between gap-3 p-5 font-bold" style={{ ["--reveal-delay" as string]: `${i * 60}ms` }}>
                {title}
                <span aria-hidden="true" className="text-flow-orange">→</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ============ CENA 7 — ARQUITETURA INTEGRADA ============ */}
      <section data-scene="conexao" className="surface-deep py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="eyebrow reveal">Arquitetura integrada</p>
            <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl lg:text-5xl">
              O marketing gera. A IA executa. O sistema controla.
            </h2>
            <p className="reveal mx-auto mt-5 max-w-2xl text-flow-muted">
              Tráfego, site, formulário, WhatsApp, CRM, IA, sistema e dashboard
              funcionando como um único organismo — cada oportunidade
              registrada, cada etapa medida.
            </p>
          </div>

          <div className="relative mt-14">
            <svg className="absolute inset-x-0 top-1/2 hidden h-24 w-full -translate-y-1/2 lg:block" viewBox="0 0 1200 100" fill="none" preserveAspectRatio="none" aria-hidden="true">
              <path
                data-connect-path
                d="M40 50 H 1160"
                stroke="url(#arch-grad)"
                strokeWidth="2"
                strokeLinecap="round"
              />
              <defs>
                <linearGradient id="arch-grad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#2B313A" />
                  <stop offset="50%" stopColor="#FF6A00" />
                  <stop offset="100%" stopColor="#FFB347" />
                </linearGradient>
              </defs>
            </svg>
            <ol className="relative grid gap-4 sm:grid-cols-2 lg:grid-cols-8">
              {["Tráfego", "Site", "Formulário", "WhatsApp", "CRM", "IA", "Sistema", "Dashboard"].map((t, i) => (
                <li key={t} className="card reveal flex flex-col items-center gap-2 p-5 text-center" style={{ ["--reveal-delay" as string]: `${i * 50}ms` }}>
                  <span className="kbd-dot" aria-hidden="true" />
                  <span className="text-sm font-bold">{t}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* ============ CENA — COMO TRABALHAMOS ============ */}
      <section id="como-trabalhamos" className="py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="eyebrow reveal">Como trabalhamos</p>
            <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl lg:text-5xl">
              Menos promessa. Mais método.
            </h2>
          </div>

          <ol className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Diagnóstico", "Entendemos o cenário, os gargalos e a prioridade real da sua operação."],
              ["Mapeamento", "Processos, ferramentas, dados e pessoas — documentados como realmente funcionam."],
              ["Estratégia e arquitetura", "Definimos a solução: o que automatizar, o que integrar, o que construir."],
              ["Protótipo", "Você valida a solução em versão navegável antes do desenvolvimento pesado."],
              ["Implantação", "Entrega por etapas, com treinamento da equipe e migração organizada."],
              ["Operação", "A estrutura roda no dia a dia com suporte e monitoramento."],
              ["Otimização e evolução", "Dados viram ajustes: cada ciclo deixa a operação melhor que o anterior."],
            ].map(([title, desc], i) => (
              <li key={title} className="card reveal p-6" style={{ ["--reveal-delay" as string]: `${(i % 4) * 70}ms` }}>
                <span className="text-sm font-extrabold text-flow-orange">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-2 font-bold">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-flow-muted">{desc}</p>
              </li>
            ))}
            <li className="card reveal flex items-center justify-center border-flow-orange/40 p-6" style={{ ["--reveal-delay" as string]: "280ms" }}>
              <Link href="/diagnostico/" className="text-center font-extrabold text-flow-amber hover:text-white">
                Começar pelo diagnóstico →
              </Link>
            </li>
          </ol>
        </div>
      </section>

      {/* ============ CENA — SOLUÇÕES POR NECESSIDADE ============ */}
      <section className="surface-deep py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="eyebrow reveal">Por onde começar</p>
            <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl lg:text-5xl">
              Comece pela sua necessidade.
            </h2>
          </div>

          <div className="mt-14 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {[
              ["Quero gerar mais oportunidades", "/gestao-de-trafego-pago/"],
              ["Quero converter melhor", "/sites-e-landing-pages/"],
              ["Quero automatizar tarefas", "/automacao-de-processos-com-ia/"],
              ["Quero organizar meu comercial", "/crm-personalizado-e-automacao-de-vendas/"],
              ["Quero integrar meus sistemas", "/integracoes-de-sistemas-e-apis/"],
              ["Quero desenvolver um sistema próprio", "/desenvolvimento-de-sistemas-personalizados/"],
              ["Quero criar um SaaS", "/desenvolvimento-de-saas-e-mvp/"],
              ["Quero melhorar minha presença no Google", "/seo-e-conteudo/"],
              ["Quero saber de onde vêm minhas vendas", "/tracking-e-analytics/"],
            ].map(([label, href], i) => (
              <Link key={href + label} href={href} className="option-pill reveal !flex items-center justify-between gap-3" style={{ ["--reveal-delay" as string]: `${(i % 3) * 60}ms` }}>
                {label}
                <span aria-hidden="true" className="shrink-0 text-flow-orange">→</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ============ CENA — PROVAS / CASES (preparada, sem invenção) ============ */}
      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="eyebrow reveal">Método na prática</p>
            <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl">
              Como uma operação conectada funciona de verdade.
            </h2>
            <p className="reveal mx-auto mt-5 max-w-2xl text-flow-muted">
              Os exemplos abaixo são demonstrações da metodologia FlowAI — não
              são resultados de clientes. Cases reais e autorizados serão
              publicados na página de cases.
            </p>
          </div>

          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            {[
              ["Demonstração · Comercial", "Operação comercial conectada", "Lead entra pelo anúncio, é atendido e qualificado pela IA no WhatsApp, entra no CRM com origem registrada e a equipe recebe o resumo pronto para fechar."],
              ["Demonstração · Processos", "Rotina interna automatizada", "Documentos, aprovações e atualizações que antes dependiam de planilha passam a rodar em fluxo automático, com trilha de auditoria e alertas."],
              ["Demonstração · Software", "Sistema sob medida em evolução", "Um portal interno nasce como MVP focado no gargalo principal e evolui em ciclos: novos módulos, integrações e painéis conforme a operação cresce."],
            ].map(([tag, title, desc], i) => (
              <article key={title} className="card card--hover reveal p-8" style={{ ["--reveal-delay" as string]: `${i * 90}ms` }}>
                <p className="chip !text-[11px]">{tag}</p>
                <h3 className="mt-4 text-xl font-extrabold">{title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-flow-muted">{desc}</p>
              </article>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Link href="/cases/" className="font-bold text-flow-amber hover:text-white">
              Ver a página de cases →
            </Link>
          </div>
        </div>
      </section>

      {/* ============ CENA 8 — DIAGNÓSTICO ============ */}
      <section
        className="relative overflow-hidden py-24 md:py-32"
        style={{
          background:
            "radial-gradient(900px 500px at 50% 120%, rgba(255,106,0,0.14), transparent 60%), #0F141B",
        }}
      >
        <div className="mx-auto max-w-4xl px-5 text-center lg:px-8">
          <p className="eyebrow reveal">Diagnóstico gratuito</p>
          <h2 className="h-section reveal mt-4 text-3xl sm:text-4xl lg:text-5xl">
            Descubra o que está travando o crescimento da sua empresa.
          </h2>
          <p className="reveal mx-auto mt-5 max-w-2xl text-flow-muted">
            Em poucos minutos, você responde sobre sua operação e recebe uma
            leitura inicial com a prioridade recomendada — direto no seu
            WhatsApp, sem compromisso.
          </p>
          <div className="reveal mt-9">
            <Link href="/diagnostico/" className="btn btn--primary">
              Fazer meu diagnóstico agora
            </Link>
          </div>
          <p className="reveal mt-4 text-xs text-flow-muted">
            Leva menos de 3 minutos · Seus dados são protegidos conforme a{" "}
            <Link href="/politica-de-privacidade/" className="underline hover:text-white">
              Política de Privacidade
            </Link>
          </p>
        </div>
      </section>

      {/* ============ FAQ ============ */}
      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-3xl px-5 lg:px-8">
          <p className="eyebrow reveal text-center">Perguntas frequentes</p>
          <h2 className="h-section reveal mt-4 text-center text-3xl sm:text-4xl">
            O que as empresas nos perguntam antes de começar.
          </h2>
          <div className="reveal mt-12">
            <Faq items={HOME_FAQ} />
          </div>
        </div>
      </section>

      {/* ============ CENA 9 — CTA FINAL ============ */}
      <section
        className="relative overflow-hidden py-28 md:py-36"
        style={{
          background:
            "radial-gradient(1000px 600px at 50% 0%, rgba(255,106,0,0.12), transparent 55%), #070A0F",
        }}
      >
        <div className="mx-auto max-w-4xl px-5 text-center lg:px-8">
          <div className="reveal mx-auto mb-10 w-full max-w-xl opacity-90">
            <FlowCore />
          </div>
          <h2 className="h-display reveal text-3xl sm:text-5xl">
            Vamos construir a próxima fase da sua empresa.
          </h2>
          <div className="reveal mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link href="/diagnostico/" className="btn btn--primary w-full sm:w-auto">
              Fazer diagnóstico
            </Link>
            <a
              href={buildWaLink(WA_MESSAGES.default)}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn--ghost w-full sm:w-auto"
            >
              Falar pelo WhatsApp
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
