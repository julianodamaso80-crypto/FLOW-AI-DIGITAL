import type { MetadataRoute } from "next";
import { SERVICES } from "@/content/services";
import { SITE_URL } from "@/lib/site";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date("2026-07-29");

  const staticPages = [
    { path: "/", priority: 1.0 },
    { path: "/diagnostico/", priority: 0.9 },
    { path: "/sobre/", priority: 0.6 },
    { path: "/cases/", priority: 0.6 },
    { path: "/blog/", priority: 0.6 },
    { path: "/contato/", priority: 0.6 },
    { path: "/politica-de-privacidade/", priority: 0.3 },
    { path: "/termos-de-uso/", priority: 0.3 },
  ];

  return [
    ...staticPages.map((p) => ({
      url: `${SITE_URL}${p.path}`,
      lastModified,
      changeFrequency: "weekly" as const,
      priority: p.priority,
    })),
    ...SERVICES.map((s) => ({
      url: `${SITE_URL}/${s.slug}/`,
      lastModified,
      changeFrequency: "weekly" as const,
      priority: 0.8,
    })),
  ];
}
