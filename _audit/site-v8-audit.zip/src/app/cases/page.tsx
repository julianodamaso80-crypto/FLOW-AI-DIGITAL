import type { Metadata } from "next";
import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import { breadcrumbSchema } from "@/lib/schema";

export const metadata: Metadata = {
  title: "Cases — Projetos e Metodologia FlowAI",
  description:
    "Conheça a metodologia FlowAI na prática. Publicamos apenas cases reais e autorizados pelos clientes — sem números inventados e sem depoimentos fabricados.",
  alternates: { canonical: "/cases/" },
};

export default function CasesPage() {
  return (
    <>
      <JsonLd
        data={breadcrumbSchema([
          { name: "Início", path: "/" },
          { name: "Cases", path: "/cases/" },
        ])}
      />
      <section
        className="pb-16 pt-32 md:pt-40"
        style={{
          background:
            "radial-gradient(1000px 480px at 50% -10%, rgba(255,106,0,0.10), transparent 60%), #0F141B",
        }}
      >
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <p className="eyebrow hero-enter">Cases</p>
          <h1 className="h-display mt-4 text-3xl sm:text-5xl">
            Provas de verdade — ou nenhuma.
          </h1>
          <p className="hero-enter mt-6 max-w-2xl text-lg leading-relaxed text-flow-muted">
            Nesta página publicamos apenas cases reais, com autorização expressa
            dos clientes: contexto, problema, solução, tecnologia, processo e
            resultado comprovado. Nada de depoimento fabricado, foto de banco de
            imagem ou percentual inventado.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <div className="card border-flow-orange/30 p-8">
            <p className="eyebrow !text-[11px]">Em preparação</p>
            <h2 className="mt-3 text-2xl font-extrabold">
              Os primeiros cases autorizados estão em processo de documentação.
            </h2>
            <p className="mt-4 leading-relaxed text-flow-muted">
              Estamos coletando as autorizações e organizando os dados
              comprovados dos projetos. Enquanto isso, você pode conhecer a
              metodologia completa da FlowAI e ver demonstrações do método na
              página inicial — sempre claramente identificadas como
              demonstrações, nunca como resultado de cliente.
            </p>
            <div className="mt-7 flex flex-col gap-4 sm:flex-row">
              <Link href="/#como-trabalhamos" className="btn btn--ghost">
                Conhecer a metodologia
              </Link>
              <Link href="/diagnostico/" className="btn btn--primary">
                Fazer diagnóstico gratuito
              </Link>
            </div>
          </div>

          <div className="prose-flow mt-14">
            <h2>O que você vai encontrar em cada case publicado</h2>
            <ul>
              <li><strong>Contexto:</strong> segmento, porte e momento da empresa.</li>
              <li><strong>Problema:</strong> o gargalo real que motivou o projeto.</li>
              <li><strong>Solução:</strong> o que foi construído e por quê.</li>
              <li><strong>Tecnologia:</strong> as ferramentas e integrações utilizadas.</li>
              <li><strong>Processo:</strong> como o projeto aconteceu, fase a fase.</li>
              <li><strong>Resultado comprovado:</strong> apenas números autorizados e verificáveis — quando não houver número autorizado, descrevemos a transformação operacional.</li>
              <li><strong>Período e autorização:</strong> quando aconteceu e a confirmação de que o cliente aprovou a publicação.</li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
}
