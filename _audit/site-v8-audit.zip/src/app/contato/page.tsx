import type { Metadata } from "next";
import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import { breadcrumbSchema } from "@/lib/schema";
import { buildWaLink, WHATSAPP_DISPLAY, INSTAGRAM_URL } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contato — Fale com a FlowAI Digital",
  description:
    "Fale com a FlowAI Digital pelo WhatsApp ou Instagram, ou comece pelo diagnóstico gratuito. Atendimento para empresas de todo o Brasil.",
  alternates: { canonical: "/contato/" },
};

export default function ContatoPage() {
  return (
    <>
      <JsonLd
        data={breadcrumbSchema([
          { name: "Início", path: "/" },
          { name: "Contato", path: "/contato/" },
        ])}
      />
      <section
        className="pb-24 pt-32 md:pt-40"
        style={{
          background:
            "radial-gradient(900px 480px at 50% -10%, rgba(255,106,0,0.10), transparent 60%), #070A0F",
        }}
      >
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <p className="eyebrow hero-enter">Contato</p>
          <h1 className="h-display mt-4 text-3xl sm:text-5xl">
            Vamos conversar sobre a sua operação.
          </h1>
          <p className="hero-enter mt-5 max-w-xl text-flow-muted">
            O caminho mais rápido é o WhatsApp — você fala direto com quem
            entende do assunto, sem fila de robô genérico.
          </p>

          <div className="mt-12 grid gap-5 sm:grid-cols-2">
            <a
              href={buildWaLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="card card--hover reveal p-7"
            >
              <p className="eyebrow !text-[11px]">WhatsApp</p>
              <p className="mt-3 text-xl font-extrabold">{WHATSAPP_DISPLAY}</p>
              <p className="mt-2 text-sm text-flow-muted">
                Resposta em horário comercial. Clique para abrir a conversa.
              </p>
            </a>

            <Link href="/diagnostico/" className="card card--hover reveal p-7" style={{ ["--reveal-delay" as string]: "80ms" }}>
              <p className="eyebrow !text-[11px]">Diagnóstico gratuito</p>
              <p className="mt-3 text-xl font-extrabold">Comece pela análise</p>
              <p className="mt-2 text-sm text-flow-muted">
                Responda o diagnóstico e chegue à conversa com o cenário mapeado.
              </p>
            </Link>

            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="card card--hover reveal p-7"
              style={{ ["--reveal-delay" as string]: "160ms" }}
            >
              <p className="eyebrow !text-[11px]">Instagram</p>
              <p className="mt-3 text-xl font-extrabold">@flowaidigital</p>
              <p className="mt-2 text-sm text-flow-muted">
                Conteúdo sobre marketing, IA e sistemas para empresas.
              </p>
            </a>

            <div className="card reveal p-7" style={{ ["--reveal-delay" as string]: "240ms" }}>
              <p className="eyebrow !text-[11px]">Localização</p>
              <p className="mt-3 text-xl font-extrabold">Rio de Janeiro · RJ</p>
              <p className="mt-2 text-sm text-flow-muted">
                Empresa sediada no Rio de Janeiro, com atendimento para
                empresas em todo o Brasil.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
