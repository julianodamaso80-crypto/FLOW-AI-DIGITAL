import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Termos de Uso",
  description:
    "Termos de Uso do site da FlowAI Digital: condições de utilização do conteúdo, do diagnóstico gratuito e dos canais de contato.",
  alternates: { canonical: "/termos-de-uso/" },
};

export default function TermosPage() {
  return (
    <section className="pb-24 pt-32 md:pt-40">
      <div className="prose-flow mx-auto max-w-3xl px-5 lg:px-8">
        <p className="eyebrow">Documento legal</p>
        <h1 className="h-display mt-4 mb-8 text-3xl sm:text-4xl">Termos de Uso</h1>
        <p>
          <strong>Última atualização:</strong> julho de 2026.
        </p>
        <p>
          Ao acessar o site da <strong>FlowAI Digital</strong>, você concorda
          com estes Termos de Uso. Se não concordar, recomendamos não utilizar
          o site.
        </p>

        <h2>1. Objeto do site</h2>
        <p>
          Este site apresenta os serviços da FlowAI Digital — marketing
          digital, inteligência artificial, automação e desenvolvimento de
          sistemas personalizados — e oferece um diagnóstico empresarial
          gratuito e canais de contato.
        </p>

        <h2>2. O diagnóstico gratuito</h2>
        <p>
          O diagnóstico disponível no site produz uma <strong>leitura inicial</strong>{" "}
          baseada exclusivamente nas respostas fornecidas. Ele não constitui
          consultoria formal, promessa de resultado ou proposta comercial
          vinculante. A validação completa depende de análise da operação,
          realizada em contato posterior.
        </p>

        <h2>3. Propriedade intelectual</h2>
        <p>
          Marca, logotipo, textos, layout e demais elementos deste site
          pertencem à FlowAI Digital ou são utilizados sob licença. É vedada a
          reprodução sem autorização prévia, ressalvadas citações com crédito.
        </p>

        <h2>4. Responsabilidades</h2>
        <ul>
          <li>
            Nos empenhamos para manter as informações do site corretas e
            atualizadas, mas elas têm caráter informativo e podem mudar sem
            aviso.
          </li>
          <li>
            Condições comerciais, escopos e prazos são definidos apenas em
            proposta e contrato específicos.
          </li>
          <li>
            Não nos responsabilizamos por indisponibilidades causadas por
            terceiros (hospedagem, provedores, plataformas de mensagem).
          </li>
        </ul>

        <h2>5. Links e serviços de terceiros</h2>
        <p>
          O site contém links para serviços de terceiros (como WhatsApp e
          Instagram), que possuem termos e políticas próprios.
        </p>

        <h2>6. Privacidade</h2>
        <p>
          O tratamento de dados pessoais é regido pela nossa{" "}
          <Link href="/politica-de-privacidade/">Política de Privacidade</Link>.
        </p>

        <h2>7. Alterações</h2>
        <p>
          Estes termos podem ser atualizados a qualquer momento. A versão
          vigente é sempre a publicada nesta página.
        </p>

        <h2>8. Contato</h2>
        <p>
          Dúvidas sobre estes termos? <Link href="/contato/">Fale com a FlowAI</Link>.
        </p>
      </div>
    </section>
  );
}
