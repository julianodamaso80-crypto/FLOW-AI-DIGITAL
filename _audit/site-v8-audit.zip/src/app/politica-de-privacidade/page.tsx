import type { Metadata } from "next";
import Link from "next/link";
import { WHATSAPP_DISPLAY } from "@/lib/site";

export const metadata: Metadata = {
  title: "Política de Privacidade",
  description:
    "Política de Privacidade da FlowAI Digital: como coletamos, usamos e protegemos os dados pessoais informados no site e no diagnóstico, conforme a LGPD.",
  alternates: { canonical: "/politica-de-privacidade/" },
  robots: { index: true, follow: true },
};

export default function PoliticaPage() {
  return (
    <section className="pb-24 pt-32 md:pt-40">
      <div className="prose-flow mx-auto max-w-3xl px-5 lg:px-8">
        <p className="eyebrow">Documento legal</p>
        <h1 className="h-display mt-4 mb-8 text-3xl sm:text-4xl">
          Política de Privacidade
        </h1>
        <p>
          <strong>Última atualização:</strong> julho de 2026.
        </p>
        <p>
          Esta Política de Privacidade descreve como a <strong>FlowAI Digital</strong>{" "}
          (&ldquo;FlowAI&rdquo;, &ldquo;nós&rdquo;) coleta, utiliza e protege os
          dados pessoais dos visitantes deste site, em conformidade com a Lei
          Geral de Proteção de Dados (Lei nº 13.709/2018 — LGPD).
        </p>

        <h2>1. Quais dados coletamos</h2>
        <ul>
          <li>
            <strong>Dados informados por você</strong> no diagnóstico e em
            formulários de contato: nome completo, WhatsApp, nome da empresa,
            Instagram da empresa e, opcionalmente, site e e-mail profissional —
            além das respostas às perguntas do diagnóstico.
          </li>
          <li>
            <strong>Dados de navegação</strong>: página de origem, referrer e
            parâmetros de campanha (UTMs), utilizados para entender como você
            chegou até nós.
          </li>
        </ul>

        <h2>2. Para que usamos os dados</h2>
        <ul>
          <li>Realizar o diagnóstico solicitado e apresentar a leitura inicial do seu cenário.</li>
          <li>Entrar em contato sobre as soluções apresentadas, pelo WhatsApp ou e-mail informado.</li>
          <li>Melhorar o conteúdo e a experiência do site.</li>
        </ul>
        <p>
          A base legal do tratamento é o <strong>consentimento</strong> (art.
          7º, I, da LGPD), coletado de forma destacada antes do início do
          diagnóstico, e o <strong>legítimo interesse</strong> para dados de
          navegação, sempre com minimização de coleta.
        </p>

        <h2>3. Com quem compartilhamos</h2>
        <p>
          Não vendemos dados pessoais. Os dados podem ser processados por
          ferramentas que utilizamos para operar o atendimento (como o
          WhatsApp, da Meta) e infraestrutura de hospedagem, sempre limitados
          à finalidade descrita nesta política.
        </p>

        <h2>4. Por quanto tempo guardamos</h2>
        <p>
          Pelo tempo necessário para as finalidades descritas ou até a
          revogação do consentimento, ressalvadas obrigações legais de
          conservação.
        </p>

        <h2>5. Seus direitos</h2>
        <p>Você pode, a qualquer momento, solicitar:</p>
        <ul>
          <li>Confirmação de que tratamos seus dados e acesso a eles.</li>
          <li>Correção de dados incompletos ou desatualizados.</li>
          <li>Exclusão dos dados tratados com base no consentimento.</li>
          <li>Revogação do consentimento.</li>
        </ul>
        <p>
          Para exercer qualquer direito, fale com a gente pelo WhatsApp{" "}
          {WHATSAPP_DISPLAY}. Responderemos no menor prazo possível.
        </p>

        <h2>6. Segurança</h2>
        <p>
          Adotamos medidas técnicas e organizacionais para proteger os dados
          contra acessos não autorizados: comunicação via HTTPS, coleta mínima
          necessária e controle de acesso às informações.
        </p>

        <h2>7. Cookies e medição</h2>
        <p>
          Este site pode utilizar ferramentas de análise de audiência e de
          medição de campanhas. Quando aplicável, o uso dessas tecnologias
          respeitará as configurações do seu navegador e a legislação vigente.
        </p>

        <h2>8. Alterações desta política</h2>
        <p>
          Esta política pode ser atualizada para refletir mudanças no site ou
          na legislação. A data da última atualização aparece no topo da
          página.
        </p>

        <p>
          Dúvidas? <Link href="/contato/">Fale com a FlowAI</Link>.
        </p>
      </div>
    </section>
  );
}
