import type { Metadata } from "next";
import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import { breadcrumbSchema } from "@/lib/schema";
import { buildWaLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "Sobre a FlowAI Digital — Crescimento e Tecnologia em Uma Só Operação",
  description:
    "Conheça a FlowAI Digital: empresa carioca que une marketing digital, inteligência artificial, automação e desenvolvimento de sistemas personalizados em uma única operação.",
  alternates: { canonical: "/sobre/" },
};

export default function SobrePage() {
  return (
    <>
      <JsonLd
        data={breadcrumbSchema([
          { name: "Início", path: "/" },
          { name: "Sobre", path: "/sobre/" },
        ])}
      />
      <section
        className="pb-16 pt-32 md:pt-40"
        style={{
          background:
            "radial-gradient(1000px 480px at 50% -10%, rgba(255,106,0,0.10), transparent 60%), #0F141B",
        }}
      >
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <p className="eyebrow hero-enter">Sobre a FlowAI</p>
          <h1 className="h-display mt-4 text-3xl sm:text-5xl">
            Crescimento e tecnologia trabalhando como{" "}
            <span className="text-flow-orange">uma só operação</span>.
          </h1>
          <p className="hero-enter mt-6 max-w-2xl text-lg leading-relaxed text-flow-muted">
            A FlowAI Digital conecta estratégia de marketing, inteligência
            artificial, automação, dados e sistemas personalizados para
            transformar processos dispersos em uma operação organizada,
            mensurável e escalável.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <div className="prose-flow">
            <h2>Por que existimos</h2>
            <p>
              A maioria das empresas não sofre por falta de ferramenta ou de
              fornecedor — sofre porque marketing, atendimento, vendas e
              tecnologia funcionam como mundos separados. A agência entrega
              lead, o comercial não responde a tempo, o CRM não reflete a
              realidade e o sistema não conversa com nada. Cada parte até
              funciona; o conjunto, não.
            </p>
            <p>
              A FlowAI nasceu para atacar esse problema pela raiz: planejar e
              construir soluções conectadas, unindo marketing, IA, automação,
              software e dados em uma única operação — com um só responsável
              pela estrutura inteira.
            </p>

            <h2>O que nos guia</h2>
            <ul>
              <li>
                <strong>Clareza:</strong> explicar o complexo de forma simples,
                sem jargão para impressionar.
              </li>
              <li>
                <strong>Resultado:</strong> tecnologia precisa gerar impacto
                real na operação — ou não deveria existir.
              </li>
              <li>
                <strong>Personalização:</strong> a solução se adapta ao
                negócio, nunca o contrário.
              </li>
              <li>
                <strong>Integração:</strong> ferramentas e equipes precisam
                conversar.
              </li>
              <li>
                <strong>Evolução:</strong> todo sistema nasce para melhorar em
                ciclos contínuos.
              </li>
              <li>
                <strong>Responsabilidade:</strong> IA com segurança, revisão e
                transparência — pessoas nas decisões que importam.
              </li>
            </ul>

            <h2>Como trabalhamos</h2>
            <p>
              Todo projeto começa por um diagnóstico honesto: entender o
              cenário, os gargalos e a prioridade real — inclusive quando a
              resposta certa é &ldquo;você ainda não precisa disso&rdquo;. A
              partir daí, o método segue por mapeamento, arquitetura da
              solução, protótipo, implantação acompanhada e evolução contínua.
              Menos promessa, mais método.
            </p>
            <p>
              Somos sediados no Rio de Janeiro e atendemos empresas de todo o
              Brasil, com reuniões online e acompanhamento estruturado.
            </p>
          </div>

          <div className="mt-14 flex flex-col gap-4 sm:flex-row">
            <Link href="/diagnostico/" className="btn btn--primary">
              Fazer diagnóstico gratuito
            </Link>
            <a
              href={buildWaLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn--ghost"
            >
              Falar com a FlowAI
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
