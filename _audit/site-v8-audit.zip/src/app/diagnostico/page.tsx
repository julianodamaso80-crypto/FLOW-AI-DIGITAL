import type { Metadata } from "next";
import Quiz from "@/components/quiz/Quiz";
import JsonLd from "@/components/JsonLd";
import { breadcrumbSchema } from "@/lib/schema";

export const metadata: Metadata = {
  title: "Diagnóstico Empresarial Gratuito — Marketing, IA e Sistemas",
  description:
    "Descubra o que está travando o crescimento da sua empresa: responda o diagnóstico gratuito da FlowAI e receba a leitura inicial com a prioridade recomendada.",
  alternates: { canonical: "/diagnostico/" },
  openGraph: {
    title: "Diagnóstico Empresarial Gratuito | FlowAI Digital",
    description:
      "Em poucos minutos, uma leitura inicial da sua operação: marketing, IA e sistemas.",
    url: "/diagnostico/",
  },
};

export default function DiagnosticoPage() {
  return (
    <>
      <JsonLd
        data={breadcrumbSchema([
          { name: "Início", path: "/" },
          { name: "Diagnóstico", path: "/diagnostico/" },
        ])}
      />
      <section
        className="pb-24 pt-32 md:pt-40"
        style={{
          background:
            "radial-gradient(900px 480px at 50% -10%, rgba(255,106,0,0.10), transparent 60%), #070A0F",
        }}
      >
        <div className="mx-auto max-w-3xl px-5 lg:px-8">
          <div className="mb-12 text-center">
            <p className="eyebrow">Diagnóstico gratuito</p>
            <h1 className="h-display mt-4 text-3xl sm:text-4xl lg:text-5xl">
              Descubra o que está travando o crescimento da sua empresa.
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-flow-muted">
              Responda sobre sua operação e receba uma leitura inicial com a
              prioridade recomendada — direto no seu WhatsApp.
            </p>
          </div>
          <div className="card p-6 sm:p-10">
            <Quiz />
          </div>
        </div>
      </section>
    </>
  );
}
