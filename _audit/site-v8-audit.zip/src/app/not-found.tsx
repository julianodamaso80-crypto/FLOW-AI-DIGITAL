import Link from "next/link";

export default function NotFound() {
  return (
    <section className="flex min-h-[70vh] items-center pb-24 pt-32">
      <div className="mx-auto max-w-xl px-5 text-center lg:px-8">
        <p className="eyebrow">Erro 404</p>
        <h1 className="h-display mt-4 text-4xl sm:text-5xl">
          Esta página saiu do fluxo.
        </h1>
        <p className="mt-5 text-flow-muted">
          O endereço que você acessou não existe ou mudou de lugar. Vamos te
          levar de volta para o caminho certo.
        </p>
        <div className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link href="/" className="btn btn--primary">
            Ir para a página inicial
          </Link>
          <Link href="/diagnostico/" className="btn btn--ghost">
            Fazer diagnóstico gratuito
          </Link>
        </div>
      </div>
    </section>
  );
}
