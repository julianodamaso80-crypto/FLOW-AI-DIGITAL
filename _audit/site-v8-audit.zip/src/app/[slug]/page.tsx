import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Faq from "@/components/Faq";
import JsonLd from "@/components/JsonLd";
import WaContextButton from "@/components/WaContextButton";
import { SERVICES, getService } from "@/content/services";
import { PILLAR_LABELS } from "@/lib/site";
import { serviceSchema, breadcrumbSchema, faqSchema } from "@/lib/schema";

export const dynamicParams = false;

export function generateStaticParams() {
  return SERVICES.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) return {};
  return {
    title: service.metaTitle,
    description: service.metaDescription,
    alternates: { canonical: `/${service.slug}/` },
    openGraph: {
      title: service.metaTitle,
      description: service.metaDescription,
      url: `/${service.slug}/`,
    },
  };
}

export default async function ServicePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) notFound();

  const path = `/${service.slug}/`;

  return (
    <>
      <JsonLd
        data={serviceSchema({
          name: service.breadcrumbLabel,
          description: service.metaDescription,
          path,
        })}
      />
      <JsonLd
        data={breadcrumbSchema([
          { name: "Início", path: "/" },
          { name: PILLAR_LABELS[service.pillar], path: "/#pilares" },
          { name: service.breadcrumbLabel, path },
        ])}
      />
      <JsonLd data={faqSchema(service.faq)} />

      {/* HERO */}
      <section
        className="relative overflow-hidden pb-16 pt-32 md:pt-40"
        style={{
          background:
            "radial-gradient(1000px 480px at 50% -10%, rgba(255,106,0,0.10), transparent 60%), linear-gradient(180deg, #0F141B 0%, #070A0F 75%)",
        }}
      >
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <nav aria-label="Breadcrumb" className="hero-enter">
            <ol className="flex flex-wrap items-center gap-2 text-[13px] text-flow-muted">
              <li>
                <Link href="/" className="hover:text-white">
                  Início
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link href="/#pilares" className="hover:text-white">
                  {PILLAR_LABELS[service.pillar]}
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li aria-current="page" className="text-flow-soft">
                {service.breadcrumbLabel}
              </li>
            </ol>
          </nav>

          <h1 className="h-display mt-8 text-3xl sm:text-4xl lg:text-[52px]">
            {service.h1}
          </h1>
          <p className="hero-enter mt-6 max-w-2xl text-lg leading-relaxed text-flow-muted" style={{ ["--enter-delay" as string]: "140ms" }}>
            {service.heroText}
          </p>
          <div className="hero-enter mt-9 flex flex-col gap-4 sm:flex-row" style={{ ["--enter-delay" as string]: "210ms" }}>
            <Link href="/diagnostico/" className="btn btn--primary">
              Fazer diagnóstico gratuito
            </Link>
            <WaContextButton
              waKey={service.waKey}
              className="btn btn--ghost"
              label="Falar com um especialista"
            />
          </div>
        </div>
      </section>

      {/* PROBLEMAS */}
      <section className="py-20 md:py-24">
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <h2 className="h-section reveal text-2xl sm:text-3xl">
            {service.problemTitle}
          </h2>
          <ul className="mt-8 space-y-3">
            {service.problems.map((p, i) => (
              <li
                key={i}
                className="card reveal flex gap-4 p-5 text-[15px] text-flow-soft"
                style={{ ["--reveal-delay" as string]: `${i * 60}ms` }}
              >
                <span className="kbd-dot mt-1.5 shrink-0" aria-hidden="true" />
                {p}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* ENTREGAS */}
      <section className="surface-deep py-20 md:py-24">
        <div className="mx-auto max-w-6xl px-5 lg:px-8">
          <h2 className="h-section reveal text-2xl sm:text-3xl">
            {service.deliverablesTitle}
          </h2>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {service.deliverables.map((d, i) => (
              <div
                key={d.title}
                className="card card--hover reveal p-6"
                style={{ ["--reveal-delay" as string]: `${(i % 3) * 80}ms` }}
              >
                <h3 className="font-bold">{d.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-flow-muted">
                  {d.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESSO */}
      <section className="py-20 md:py-24">
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <h2 className="h-section reveal text-2xl sm:text-3xl">
            Como o projeto acontece
          </h2>
          <ol className="mt-10 space-y-4">
            {service.process.map((step, i) => (
              <li
                key={step.title}
                className="card reveal flex gap-5 p-6"
                style={{ ["--reveal-delay" as string]: `${i * 70}ms` }}
              >
                <span
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-flow-line font-extrabold text-flow-amber"
                  aria-hidden="true"
                >
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div>
                  <h3 className="font-bold">{step.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-flow-muted">
                    {step.desc}
                  </p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* FAQ */}
      <section className="surface-deep py-20 md:py-24">
        <div className="mx-auto max-w-3xl px-5 lg:px-8">
          <h2 className="h-section reveal text-2xl sm:text-3xl">
            Perguntas frequentes
          </h2>
          <div className="reveal mt-8">
            <Faq items={service.faq} />
          </div>
        </div>
      </section>

      {/* RELACIONADOS */}
      <section className="py-20 md:py-24">
        <div className="mx-auto max-w-6xl px-5 lg:px-8">
          <h2 className="h-section reveal text-xl sm:text-2xl">
            Soluções relacionadas
          </h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {service.related.map((r, i) => (
              <Link
                key={r.href}
                href={r.href}
                className="card card--hover reveal flex items-center justify-between gap-3 p-5 font-bold"
                style={{ ["--reveal-delay" as string]: `${i * 60}ms` }}
              >
                {r.title}
                <span aria-hidden="true" className="shrink-0 text-flow-orange">
                  →
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section
        className="py-24"
        style={{
          background:
            "radial-gradient(800px 400px at 50% 120%, rgba(255,106,0,0.14), transparent 60%), #0F141B",
        }}
      >
        <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
          <h2 className="h-section reveal text-2xl sm:text-4xl">
            {service.ctaTitle}
          </h2>
          <p className="reveal mt-4 text-flow-muted">
            Comece pelo diagnóstico gratuito — em poucos minutos você descobre a
            prioridade da sua operação.
          </p>
          <div className="reveal mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link href="/diagnostico/" className="btn btn--primary">
              Fazer diagnóstico
            </Link>
            <WaContextButton
              waKey={service.waKey}
              className="btn btn--ghost"
              label="Falar pelo WhatsApp"
            />
          </div>
        </div>
      </section>
    </>
  );
}
