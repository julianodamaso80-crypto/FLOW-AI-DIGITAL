import type { Metadata } from "next";
import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import { breadcrumbSchema } from "@/lib/schema";

export const metadata: Metadata = {
  title: "Blog — Marketing, IA e Sistemas para Empresas",
  description:
    "Conteúdo editorial da FlowAI Digital sobre marketing digital, inteligência artificial, automação e desenvolvimento de sistemas — profundo, útil e baseado em experiência real.",
  alternates: { canonical: "/blog/" },
};

const CATEGORIES = [
  {
    title: "Sistemas e software",
    desc: "Sistemas personalizados, SaaS, MVP, CRM e integrações.",
    topics: [
      "Quanto custa desenvolver um sistema personalizado?",
      "Sistema personalizado ou software pronto: qual escolher?",
      "Como funciona o desenvolvimento de um software sob medida?",
      "CRM personalizado vale a pena?",
      "Como criar um SaaS do zero?",
      "Quais são as etapas de desenvolvimento de um MVP?",
      "Como integrar sistemas antigos com ferramentas modernas?",
    ],
  },
  {
    title: "Inteligência artificial e automação",
    desc: "Agentes de IA, automação de processos e atendimento inteligente.",
    topics: [
      "O que são agentes de IA para empresas?",
      "Como automatizar o atendimento pelo WhatsApp?",
      "Quais processos podem ser automatizados com inteligência artificial?",
      "Chatbot tradicional ou agente de IA?",
      "Como utilizar IA na qualificação de leads?",
      "Como automatizar o follow-up comercial?",
      "Como calcular o retorno de uma automação?",
      "Como reduzir tarefas manuais dentro da empresa?",
    ],
  },
  {
    title: "Marketing e aquisição",
    desc: "Tráfego pago, SEO, conversão e crescimento.",
    topics: [
      "Como escolher uma agência de marketing digital?",
      "Agência tradicional ou agência de inteligência artificial?",
      "Como criar uma landing page de alta conversão?",
      "Como melhorar o posicionamento de uma empresa no Google?",
      "O que é GEO e como aparecer em respostas de inteligência artificial?",
      "Como marketing e tecnologia podem trabalhar juntos?",
    ],
  },
  {
    title: "Dados e operação comercial",
    desc: "Tracking, atribuição, dashboards e integração marketing-vendas.",
    topics: [
      "O que é tracking server-side?",
      "Como descobrir qual campanha realmente gerou uma venda?",
      "Como integrar CRM, marketing e vendas?",
      "Como criar um dashboard comercial personalizado?",
    ],
  },
];

export default function BlogPage() {
  return (
    <>
      <JsonLd
        data={breadcrumbSchema([
          { name: "Início", path: "/" },
          { name: "Blog", path: "/blog/" },
        ])}
      />
      <section
        className="pb-16 pt-32 md:pt-40"
        style={{
          background:
            "radial-gradient(1000px 480px at 50% -10%, rgba(255,106,0,0.10), transparent 60%), #0F141B",
        }}
      >
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <p className="eyebrow hero-enter">Conteúdo</p>
          <h1 className="h-display mt-4 text-3xl sm:text-5xl">
            Conteúdo para quem decide: profundo, útil, sem enrolação.
          </h1>
          <p className="hero-enter mt-6 max-w-2xl text-lg leading-relaxed text-flow-muted">
            Os primeiros artigos estão em produção — escritos com base em
            experiência real de projeto, não em texto genérico de IA. Abaixo,
            as linhas editoriais e os temas que vêm por aí.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-6xl px-5 lg:px-8">
          <div className="grid gap-6 md:grid-cols-2">
            {CATEGORIES.map((cat, i) => (
              <div key={cat.title} className="card reveal p-8" style={{ ["--reveal-delay" as string]: `${(i % 2) * 80}ms` }}>
                <h2 className="text-xl font-extrabold">{cat.title}</h2>
                <p className="mt-2 text-sm text-flow-muted">{cat.desc}</p>
                <ul className="mt-5 space-y-2.5">
                  {cat.topics.map((t) => (
                    <li key={t} className="flex gap-2.5 text-[14.5px] text-flow-soft">
                      <span className="kbd-dot mt-1.5 shrink-0" aria-hidden="true" />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="card mt-10 border-flow-orange/30 p-8 text-center">
            <h2 className="text-xl font-extrabold">
              Tem uma dúvida que deveria virar artigo?
            </h2>
            <p className="mx-auto mt-3 max-w-lg text-sm text-flow-muted">
              Enquanto o blog não estreia, fale direto com a gente — respondemos
              de verdade, sem esperar o texto ficar pronto.
            </p>
            <div className="mt-6">
              <Link href="/contato/" className="btn btn--primary">
                Falar com a FlowAI
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
