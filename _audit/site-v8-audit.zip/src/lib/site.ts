/**
 * Constantes centrais do site FlowAI Digital.
 * ÚNICO lugar onde o número de WhatsApp é definido.
 */

export const SITE_URL = "https://flowaidigital.com.br";
export const SITE_NAME = "FlowAI Digital";

/** Número comercial oficial e obrigatório (novo). Nunca usar o antigo 5521980214882. */
export const WHATSAPP_NUMBER = "5521992208062";
export const WHATSAPP_DISPLAY = "(21) 99220-8062";

export const INSTAGRAM_URL = "https://www.instagram.com/flowaidigital";

/** Mensagens de WhatsApp contextualizadas por área do site. */
export const WA_MESSAGES: Record<string, string> = {
  default:
    "Olá! Conheci a FlowAI pelo site e quero entender qual solução é mais adequada para minha empresa.",
  sistemas:
    "Olá! Quero conversar sobre o desenvolvimento de um sistema personalizado para minha empresa.",
  ia: "Olá! Quero entender como aplicar inteligência artificial e automação na minha empresa.",
  marketing:
    "Olá! Quero conversar sobre marketing, geração de oportunidades e crescimento.",
};

/**
 * Monta o link wa.me com mensagem contextualizada.
 * Executado no clique (client-side) para anexar URL atual e UTMs quando existirem.
 */
export function buildWaLink(message?: string): string {
  const text = message ?? WA_MESSAGES.default;
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
}

export interface NavService {
  title: string;
  href: string;
  pillar: "marketing" | "ia" | "sistemas";
}

export const SERVICES_NAV: NavService[] = [
  { title: "Marketing digital completo", href: "/agencia-de-marketing-digital/", pillar: "marketing" },
  { title: "Gestão de tráfego pago", href: "/gestao-de-trafego-pago/", pillar: "marketing" },
  { title: "SEO e conteúdo", href: "/seo-e-conteudo/", pillar: "marketing" },
  { title: "Sites e landing pages", href: "/sites-e-landing-pages/", pillar: "marketing" },
  { title: "Tracking e analytics", href: "/tracking-e-analytics/", pillar: "marketing" },
  { title: "Inteligência artificial para empresas", href: "/agencia-de-inteligencia-artificial/", pillar: "ia" },
  { title: "Automação de processos com IA", href: "/automacao-de-processos-com-ia/", pillar: "ia" },
  { title: "Agentes de IA para empresas", href: "/agentes-de-ia-para-empresas/", pillar: "ia" },
  { title: "Chatbot com IA para WhatsApp", href: "/chatbot-com-ia-para-whatsapp/", pillar: "ia" },
  { title: "Sistemas personalizados", href: "/desenvolvimento-de-sistemas-personalizados/", pillar: "sistemas" },
  { title: "SaaS, MVP e produtos digitais", href: "/desenvolvimento-de-saas-e-mvp/", pillar: "sistemas" },
  { title: "CRM personalizado e automação de vendas", href: "/crm-personalizado-e-automacao-de-vendas/", pillar: "sistemas" },
  { title: "Integrações de sistemas e APIs", href: "/integracoes-de-sistemas-e-apis/", pillar: "sistemas" },
];

export const PILLAR_LABELS: Record<NavService["pillar"], string> = {
  marketing: "Marketing e Crescimento",
  ia: "IA e Automação",
  sistemas: "Sistemas Personalizados",
};
